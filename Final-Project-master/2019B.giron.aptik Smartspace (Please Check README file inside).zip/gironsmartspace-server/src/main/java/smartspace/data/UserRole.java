package smartspace.data;

public enum UserRole {
	
	PLAYER, MANAGER, ADMIN;
}
