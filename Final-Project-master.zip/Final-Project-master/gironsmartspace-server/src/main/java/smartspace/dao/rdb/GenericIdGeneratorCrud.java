package smartspace.dao.rdb;


import org.springframework.data.repository.CrudRepository;

public interface GenericIdGeneratorCrud 
	extends CrudRepository<GenericIdGenerator, Long>{

}
