package smartspace.data;

public interface SmartSpaceEntity<K> {
	
	public K getKey();
	public void setKey(K key);

}
